x = 1
y = 2
print(x + y)

#TODO: define z = 3 and print x + y + z