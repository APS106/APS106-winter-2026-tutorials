The link to the Google Slides is below:

https://docs.google.com/presentation/d/1N3Xro_ftbQR2cLKEuaVaQBcpT4E-SDML8XkM1Rjyd4U/edit?usp=sharing