x = 1
y = 2

# x = x + 1
# print(x)
# y = y * x

print(x + y)

#TODO: define z = 3 and print x + y + z